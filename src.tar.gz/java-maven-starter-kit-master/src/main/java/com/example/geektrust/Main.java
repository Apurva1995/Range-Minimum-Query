package com.example.geektrust;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import com.example.geektrust.impl.BorewellWaterBillCalculator;
import com.example.geektrust.impl.CorporationWaterBillCalculator;
import com.example.geektrust.impl.MonthlyGuestWaterConsumptionCalculator;
import com.example.geektrust.impl.MonthlyWaterAlloter;
import com.example.geektrust.impl.WaterBillCalculator;
import com.example.geektrust.impl.TankerWaterBillCalculator;
import com.example.geektrust.interfaces.IGuestWaterConsumptionCalculator;
import com.example.geektrust.interfaces.IWaterAlloter;
import com.example.geektrust.interfaces.IWaterBillCalculator;
import com.example.geektrust.interfaces.IWaterBillCalculatorStrategy;
import com.example.geektrust.model.Apartment;

//Driver class
public class Main {
	
    public static void main(String[] args)  {
    	Apartment apartment = null;
    	IWaterAlloter waterAlloter =  new MonthlyWaterAlloter();
    	IGuestWaterConsumptionCalculator guestWaterConsumptionCalculator = new MonthlyGuestWaterConsumptionCalculator();
    	IWaterBillCalculatorStrategy billCalculatorStrategy = null;
    	WaterBillCalculator waterBillCalculator = new WaterBillCalculator();
    	IWaterBillCalculator billCalculator = waterBillCalculator;
    	int totalWaterConsumedInLitre = 0;
    	int totalCost = 0;
    	
    	if(args.length > 0) {
            File file = new File(args[0]);
            try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                String line;
                String arr[];
                String ratio[];
                while ((line = br.readLine()) != null) {
                   arr = line.split(" ");
                   if(arr[0].equals("ALLOT_WATER")) {
                	   //Allocating water to the apartment on monthly basis.
                	   apartment = new Apartment(Integer.valueOf(arr[1]));
                	   ratio = arr[2].split(":");
                	   waterAlloter.allotWater(apartment, Integer.valueOf(ratio[0]),
                			   Integer.valueOf(ratio[1]));
                   }
                   else if(arr[0].equals("ADD_GUESTS")) {
                	   //Adding guests to the apartment
                	   apartment.addGuest(Integer.valueOf(arr[1]));
                   }
                   else {
                	   //calculating total water consumption
                	   int corporationWaterConsumption = apartment.getCorporationWaterQuantity();
                	   int borewellWaterConsumption = apartment.getBorewellWaterQuantity();
                	   int tankerWaterConsumption = guestWaterConsumptionCalculator.
                			   calculateGuestWaterConsumption(apartment.getGuests());
                	   totalWaterConsumedInLitre = (apartment.getTotalAllocatedWater()
                			   + tankerWaterConsumption);
                	   
                	   //Calculating corporation water bill
                	   billCalculatorStrategy = new CorporationWaterBillCalculator();
                	   waterBillCalculator.setBillCalculator(billCalculatorStrategy);
                	   totalCost += billCalculator.
                			   calculateBill(corporationWaterConsumption);
                	   
                	   //Calculating borewell water bill
                	   billCalculatorStrategy = new BorewellWaterBillCalculator();
                	   waterBillCalculator.setBillCalculator(billCalculatorStrategy);
                	   totalCost += billCalculator.
                			   calculateBill(borewellWaterConsumption);
                	   
                	   //Calculating tanker water bill
                	   billCalculatorStrategy = new TankerWaterBillCalculator();
                	   waterBillCalculator.setBillCalculator(billCalculatorStrategy);
                	   totalCost += billCalculator.
                			   calculateBill(tankerWaterConsumption);
                	   
                	   System.out.println(totalWaterConsumedInLitre + " " + totalCost);
                   }
                }
            } catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
        }
	}
}
