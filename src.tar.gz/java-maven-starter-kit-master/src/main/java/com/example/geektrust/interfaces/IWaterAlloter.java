package com.example.geektrust.interfaces;

import com.example.geektrust.model.Apartment;

public interface IWaterAlloter {
	public void allotWater(Apartment apartment, int corporationWaterRatio, int borewellWaterRatio);
}
