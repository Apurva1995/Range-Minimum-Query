package com.example.geektrust.impl;

import com.example.geektrust.interfaces.IWaterBillCalculatorStrategy;

/*
 * Corporate water bill calcultor
 */

public class CorporationWaterBillCalculator implements IWaterBillCalculatorStrategy{

	private static final double DEFAULT_WATER_PRICE_PER_LITRE=1.0;
	
	@Override
	public int calculateBill(int waterInLitre) {
		if(waterInLitre < 0)
			return 0;
		else
			return (int) (waterInLitre * DEFAULT_WATER_PRICE_PER_LITRE);
	}

}
