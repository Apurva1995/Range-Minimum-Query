package com.example.geektrust.impl;

import com.example.geektrust.enums.ApartmentType;
import com.example.geektrust.interfaces.IWaterAlloter;
import com.example.geektrust.model.Apartment;

/*
 * Allots water to apartment on monthly basis
 */
public class MonthlyWaterAlloter implements IWaterAlloter{

	@Override
	public void allotWater(Apartment apartment, int corporationWaterRatio, int borewellWaterRatio) {
		int totalAllocatedWater = (apartment.getType()==ApartmentType.TWO_BHK ? 900:1500);
		int totalRatio = corporationWaterRatio + borewellWaterRatio;
		apartment.setTotalAllocatedWater(totalAllocatedWater);
		apartment.setCorporationWaterQuantity((int)Math.ceil(
				(double)(totalAllocatedWater * corporationWaterRatio)/totalRatio));
		apartment.setBorewellWaterQuantity((int)Math.ceil(
				(double)(totalAllocatedWater * borewellWaterRatio)/totalRatio));
	}

}
