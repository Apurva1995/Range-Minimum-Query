package com.example.geektrust.impl;

import com.example.geektrust.interfaces.IWaterBillCalculatorStrategy;

public class TankerWaterBillCalculator implements IWaterBillCalculatorStrategy{

	private double price;
	
	@Override
	public int calculateBill(int waterInLitre) {
		double totalCost = 0;
		int slab = 500;
		setPrice(slab);
		while((waterInLitre - slab) > 0) {
			totalCost += (slab * price);
			waterInLitre = waterInLitre - slab;
			slab += 500;
			setPrice(slab);
		}
		if(waterInLitre > 0)
			totalCost += (waterInLitre * price);
		return (int) totalCost;
	}

	private void setPrice(int slab) {
		if(slab <= 500)
			price = 2.0;
		else if(slab <= 1000)
			price = 3.0;
		else if(slab <= 1500)
			price = 5.0;
		else
			price = 8.0;
	}
}
