package com.example.geektrust.impl;

import com.example.geektrust.interfaces.IGuestWaterConsumptionCalculator;

/*
 * Calculates water consumption for all the guests for a month
 */
public class MonthlyGuestWaterConsumptionCalculator implements IGuestWaterConsumptionCalculator{

	private static final int DEFAULT_WATER_ALLOCATION_PER_PERSON_IN_LITRE=10;
	private static final int NUMBER_OF_DAYS_IN_A_MONTH=30;
	
	@Override
	public int calculateGuestWaterConsumption(int guests) {
		return guests * DEFAULT_WATER_ALLOCATION_PER_PERSON_IN_LITRE * NUMBER_OF_DAYS_IN_A_MONTH;
	}

}
