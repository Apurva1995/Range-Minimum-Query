package com.example.geektrust.enums;

public enum ApartmentType {
	TWO_BHK, 
	THREE_BHK;
}
