package com.example.geektrust.model;

import com.example.geektrust.enums.ApartmentType;

public class Apartment {
	private String name;
	private ApartmentType type;
	private int people;
	private int guests;
	private int corporationWaterQuantity;
	private int borewellWaterQuantity;
	private int totalAllocatedWater;
	
	public Apartment() {
		super();
	}
	
	public Apartment(int type) {
		super();
		this.setGuests(0);
		this.setType(type);
	}

	public boolean addGuest(int guests) {
		this.guests += guests;
		return true;
	}
	
	public int getTotalAllocatedWater() {
		return totalAllocatedWater;
	}

	public void setTotalAllocatedWater(int totalAllocatedWater) {
		this.totalAllocatedWater = totalAllocatedWater;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ApartmentType getType() {
		return type;
	}

	private void setType(int type) {
		this.type = (type==2) ? ApartmentType.TWO_BHK:ApartmentType.THREE_BHK;
	}

	public int getPeople() {
		return people;
	}

	public void setPeople(int people) {
		this.people = people;
	}

	public int getGuests() {
		return guests;
	}

	public void setGuests(int guests) {
		this.guests = guests;
	}

	public int getCorporationWaterQuantity() {
		return corporationWaterQuantity;
	}

	public void setCorporationWaterQuantity(int corporationWaterQuantity) {
		this.corporationWaterQuantity = corporationWaterQuantity;
	}

	public int getBorewellWaterQuantity() {
		return borewellWaterQuantity;
	}

	public void setBorewellWaterQuantity(int borewellWaterQuantity) {
		this.borewellWaterQuantity = borewellWaterQuantity;
	}
	
}
