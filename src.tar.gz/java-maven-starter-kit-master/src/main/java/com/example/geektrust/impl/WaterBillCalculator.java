package com.example.geektrust.impl;

import com.example.geektrust.interfaces.IWaterBillCalculator;
import com.example.geektrust.interfaces.IWaterBillCalculatorStrategy;

/*
 * Calculates bill for different types of waters using different strategies
 */
public class WaterBillCalculator implements IWaterBillCalculator{

	private IWaterBillCalculatorStrategy billCalculator; //Strategy pattern
	
	@Override
	public int calculateBill(int waterquantity) {
		int totalCost = 0;
		totalCost += this.billCalculator.calculateBill(waterquantity);
		return totalCost;
	}

	public IWaterBillCalculatorStrategy getBillCalculator() {
		return billCalculator;
	}

	public void setBillCalculator(IWaterBillCalculatorStrategy billCalculator) {
		this.billCalculator = billCalculator;
	}
}
