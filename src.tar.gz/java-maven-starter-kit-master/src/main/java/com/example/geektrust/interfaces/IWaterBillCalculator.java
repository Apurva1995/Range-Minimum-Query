package com.example.geektrust.interfaces;

public interface IWaterBillCalculator {
	public int calculateBill(int corporationWaterquantity);
}
