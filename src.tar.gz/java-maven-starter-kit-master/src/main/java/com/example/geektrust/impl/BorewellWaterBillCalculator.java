package com.example.geektrust.impl;

import com.example.geektrust.interfaces.IWaterBillCalculatorStrategy;

/*
 * Borewell water bill calculator
 */
public class BorewellWaterBillCalculator implements IWaterBillCalculatorStrategy{

	private static final double DEFAULT_WATER_PRICE_PER_LITRE=1.5;
	
	@Override
	public int calculateBill(int waterInLitre) {
		if(waterInLitre < 0)
			return 0;
		else
			return (int) (waterInLitre * DEFAULT_WATER_PRICE_PER_LITRE);
	}

}
