package com.example.geektrust.interfaces;

public interface IWaterBillCalculatorStrategy {
	public int calculateBill(int waterInLitre);
}
