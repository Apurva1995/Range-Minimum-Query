package com.example.geektrust.model;

import java.util.List;

public class Community {
	private String name;
	private String location; //Could use separate address class, but for simplicity left as string
	private List<Apartment> apartments;
	/*
	 * Other relevant fields can be added like Accessories, Staffs etc. Since these are not relevant in this
	 * context, they are not added.
	 */
	
	
	public Community() {
		super();
	}
	
	public Community(long id, String name, String location, List<Apartment> apartments) {
		super();
		this.name = name;
		this.location = location;
		this.apartments = apartments;
	}

	public boolean addApartment(Apartment apartment) {
		this.apartments.add(apartment);
		return true;
	}
	
	public boolean removeApartment(Apartment apartment) {
		if(this.apartments.contains(apartment)) {
			this.apartments.remove(apartment);
			return true;
		}
		return false;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public List<Apartment> getApartments() {
		return apartments;
	}

	public void setApartments(List<Apartment> apartments) {
		this.apartments = apartments;
	}
}
