package com.example.geektrust.interfaces;

public interface IGuestWaterConsumptionCalculator {
	public int calculateGuestWaterConsumption(int guests);
}
